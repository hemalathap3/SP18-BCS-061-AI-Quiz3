# tasks/views.py

from rest_framework import viewsets, permissions
from .models import Task
from .serializers import TaskSerializer
from django.contrib.auth.models import User
from rest_framework.response import Response
from rest_framework.permissions import IsAdminUser, IsAuthenticated

class TaskViewSet(viewsets.ModelViewSet):
    queryset = Task.objects.all()
    serializer_class = TaskSerializer

    def get_queryset(self):
        # Admin can view all tasks, users can only view their own tasks
        if self.request.user.is_superuser:
            return Task.objects.all()
        return Task.objects.filter(owner=self.request.user)

    def perform_create(self, serializer):
        # Automatically set the owner of the task to the current user
        serializer.save(owner=self.request.user)

    def get_permissions(self):
        if self.action in ['update', 'partial_update', 'destroy']:
            # Admins can update/delete any task; users can update/delete their own tasks
            if self.request.user.is_superuser:
                return [IsAdminUser()]
            return [permissions.IsAuthenticated()]
        return [permissions.IsAuthenticated()]
